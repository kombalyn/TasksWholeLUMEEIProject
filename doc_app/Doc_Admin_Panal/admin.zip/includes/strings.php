<?php

	$app_name = "Live Tv Show - Movies";
	$app_version = "1.0";
	$copyright = "Copyright © 2023 Noor803 Developer";
	$menu_dashboard = "Dashboard";
	$menu_category = "Manage Category Movies";
	$menu_channel = "Manage Movies";
	$menu_ads = "Manage Ads";
	$menu_notification = "Notification";
	$menu_administrator = "Administrators";
	$menu_setting = "Settings";
	$menu_channel2 = "Manage Tv Show";
	$menu_category2 = "Manage Category Tv";
	  $menu_channel3 = "TV Series";
	$menu_category3 = "Manage TV Series";
	$menu_logout = "Logout";

?>