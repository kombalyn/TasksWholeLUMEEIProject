<?php include_once ('includes/header.php'); ?>

<?php

  $categories = "SELECT COUNT(*) as num FROM tbl_category";
  $totalCategories = $connect->query($categories);
  $totalCategories = $totalCategories->fetch_array();
  $totalCategories = $totalCategories['num'];
  
  $aaa = "SELECT COUNT(*) as num FROM tbl_category2";
  $totalCategories2 = $connect->query($aaa);
  $totalCategories2 = $totalCategories2->fetch_array();
  $totalCategories2 = $totalCategories2['num'];

  $sss = "SELECT COUNT(*) as num FROM tbl_category3";
  $totalCategories3 = $connect->query($sss);
  $totalCategories3 = $totalCategories3->fetch_array();
  $totalCategories3 = $totalCategories3['num'];
  

  $videos = "SELECT COUNT(*) as num FROM tbl_channel";
  $totalVideos = $connect->query($videos);
  $totalVideos = $totalVideos->fetch_array();
  $totalVideos = $totalVideos['num'];
  
    $www = "SELECT COUNT(*) as num FROM tbl_channel2";
  $totalVideos2 = $connect->query($www);
  $totalVideos2 = $totalVideos2->fetch_array();
  $totalVideos2 = $totalVideos2['num'];
  
  
    $series = "SELECT COUNT(*) as num FROM tbl_channel3";
  $totalVideos3 = $connect->query($series);
  $totalVideos3 = $totalVideos3->fetch_array();
  $totalVideos3 = $totalVideos3['num'];

?>


    <section class="content">

    <ol class="breadcrumb">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li class="active">Home</a></li>
    </ol>

        <div class="container-fluid">
             
             <div class="row">

                <a href="category.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CATEGORY MOVIES</div>
                            <div class="color-name"><i class="material-icons">view_list</i></div>
                            <div class="color-class-name">Total ( <?php echo $totalCategories; ?> ) Categories</div>
                            <br>
                        </div>
                    </div>
                </a>
				    <a href="category2.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CATEGORY TV SHOW</div>
                            <div class="color-name"><i class="material-icons">view_list</i></div>
                            <div class="color-class-name">Total ( <?php    echo $totalCategories2; ?> ) Categories</div>
                            <br>
                        </div>
                    </div>
                </a>
                  </a>
					    <a href="category3.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CATEGORY Series Tv</div>
                            <div class="color-name"><i class="material-icons">view_list</i></div>
                            <div class="color-class-name">Total ( <?php    echo $totalCategories3; ?> ) Categories</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="channel.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CHANNEL MOVIES</div>
                            <div class="color-name"><i class="material-icons">live_tv</i></div>
                            <div class="color-class-name">Total ( <?php      echo $totalVideos; ?> ) Videos</div>
                            <br>
                        </div>
                    </div>
                </a>
				  <a href="channel2.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CHANNEL TV SHOW</div>
                            <div class="color-name"><i class="material-icons">live_tv</i></div>
                            <div class="color-class-name">Total ( <?php      echo $totalVideos2; ?> ) Videos</div>
                            <br>
                        </div>
                    </div>
                </a>
                  <a href="channel3.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">MANAGE CHANNEL Series Tv</div>
                            <div class="color-name"><i class="material-icons">live_tv</i></div>
                            <div class="color-class-name">Total ( <?php      echo $totalVideos3; ?> ) Videos</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="notification.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">NOTIFICATION</div>
                            <div class="color-name"><i class="material-icons">notifications</i></div>
                            <div class="color-class-name">Send notification to your users</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="ads.php">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name uppercase">MANAGE ADS</div>
                            <div class="color-name"><i class="material-icons">monetization_on</i></div>
                            <div class="color-class-name">App Monetization</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="admin.php">
                    <div class="col-lg-4 col-md-4 col-sm-3 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">ADMINISTRATOR</div>
                            <div class="color-name"><i class="material-icons">people</i></div>
                            <div class="color-class-name">Admin Panel Privileges</div>
                            <br>
                        </div>
                    </div>
                </a>

                <a href="settings.php">
                    <div class="col-lg-4 col-md-4 col-sm-3 col-xs-12">
                        <div class="card demo-color-box bg-blue waves-effect corner-radius col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <br>
                            <div class="color-name">SETTINGS</div>
                            <div class="color-name"><i class="material-icons">settings</i></div>
                            <div class="color-class-name">Key and Privacy Settings</div>
                            <br>
                        </div>
                    </div>
                </a>

            </div>
            
        </div>

    </section>


<?php include_once('includes/footer.php'); ?>